def return_list(check_str, func):
    if type(check_str) != str:
        check_str = str(check_str).replace("'", "")
    else:
        if check_str.find("[") != -1:
            check_str = check_str.replace("[", "").replace("]", "").replace("'", "")
    input_lst = find_seplst(check_str)
    final_lst = []
    if func == "list":
        final_lst = input_lst
    elif func == "listdate":
        for date in input_lst:
            check, final_date = date_input(date)
            final_lst.append(final_date) if check else final_lst.append("<Invalid format/input>")
    elif func == "listfloat":
        for str_value in input_lst:
            final_lst.append(float(str_value))
    return final_lst


def find_seplst(check_str):
    char_lst = ["  ", ", ", ","]
    for char in char_lst:
        count_char = check_str.count(char)
        if count_char != 0:
            check_str = check_str.replace(char, " - ", count_char)
    final_lst = list(map(str, check_str.split(" - ")))
    return final_lst


def check_sepdate(check_str):
    char_lst = ["/", ".", "-", "_"]
    for char in char_lst:
        if check_str.count(char) == 2:
            sep = char
            check = True
            break
    else:
        sep = -1
        check = False
    return check, sep


def check_date(check_str):
    """ user input: dd/mm/yyyy, dd.mm.yyyy, ddmmmyyyy, d/m/yy, ... """
    check_format, sep = check_sepdate(check_str)
    if check_format:
        if len(check_str) == 6:
            if check_str.find(sep) == 1 and check_str.find(sep, check_str.find(sep)+1) == 3:
                if int(check_str[-2:]) > 90:
                    date_str = "0" + check_str[0] + "0" + check_str[2] + "19" + check_str[-2:]
                else:
                    date_str = "0" + check_str[0] + "0" + check_str[2] + "20" + check_str[-2:]
            else:
                date_str = "<invalid format>"
        elif len(check_str) == 7:
            if check_str.find(sep) == 1 and check_str.find(sep, check_str.find(sep)+1) == 4:
                if int(check_str[-2:]) > 90:
                    date_str = "0" + check_str[0] + check_str[2:4] + "19" + check_str[-2:]
                else:
                    date_str = "0" + check_str[0] + check_str[2:4] + "20" + check_str[-2:]
            elif check_str.find(sep) == 2 and check_str.find(sep, check_str.find(sep)+1) == 4:
                if int(check_str[-2:]) > 90:
                    date_str = check_str[0:2] + "0" + check_str[3] + "19" + check_str[-2:]
                else:
                    date_str = check_str[0:2] + "0" + check_str[3] + "20" + check_str[-2:]
            else:
                date_str = "<invalid format>"
        elif len(check_str) == 8:
            if check_str.find(sep) == 2 and check_str.find(sep, check_str.find(sep) + 1) == 5:
                if int(check_str[-2:]) > 90:
                    date_str = check_str[0:2] + check_str[3:5] + "19" + check_str[-2:]
                else:
                    date_str = check_str[0:2] + check_str[3:5] + "20" + check_str[-2:]
            else:
                date_str = "<invalid format>"
        elif len(check_str) == 9:
            if check_str.find(sep) == 1 and check_str.find(sep, check_str.find(sep)+1) == 4:
                date_str = "0" + check_str[0] + check_str[2:4] + check_str[-4:]
            elif check_str.find(sep) == 2 and check_str.find(sep, check_str.find(sep)+1) == 4:
                date_str = check_str[0:2] + "0" + check_str[3] + check_str[-4:]
            else:
                date_str = "<invalid format>"
        elif len(check_str) == 10:
            date_str = check_str.replace(sep, "")
        else:
            date_str = "<invalid format>"
    elif len(check_str) == 6:
        if int(check_str[-2:]) > 90:
            date_str = check_str[0:4] + "19" + check_str[-2:]
        else:
            date_str = check_str[0:4] + "20" + check_str[-2:]
    elif len(check_str) == 8:
        date_str = check_str
    elif len(check_str) == 9:
        month_dict = {"JAN": "01",
                      "FEB": "02",
                      "MAR": "03",
                      "APR": "04",
                      "MAY": "05",
                      "JUN": "06",
                      "JUL": "07",
                      "AUG": "08",
                      "SEP": "09",
                      "OCT": "10",
                      "NOV": "11",
                      "DEC": "12"}
        keys = []
        for key in month_dict.keys():
            keys.append(key)
        month = check_str[2:5].upper()
        if month in keys:
            date_str = check_str[0:2] + month_dict[month] + check_str[5:]
        else:
            date_str = "<invalid format>"
    else:
        date_str = "<invalid format>"
    if date_str != "<invalid format>":
        day = date_str[0:2]
        month = date_str[2:4]
        year = date_str[4:]
        if check_datevalue(day, month, year):
            date = day.zfill(2) + "/" + month.zfill(2) + "/" + year.zfill(4)
        else:
            date = "<invalid date>"
    else:
        date = date_str
    return date


def check_datevalue(day, month, year):
    check = True
    day = int(day)
    month = int(month)
    year = int(year)
    if month < 1 or month > 12 or day < 0:
        check = False
    else:
        if month == 2:
            if (nhuan(year) and day > 29) or (not nhuan(year) and day > 28):
                check = False
        elif month in [4, 6, 9, 11]:
            if day > 30:
                check = False
        else:
            if day > 31:
                check = False
    return check


def nhuan(year):
    check_nhuan = True if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0) else False
    return check_nhuan


def lst_input(user_input):
    user_input = return_list(user_input, "list")
    return user_input


def date_input(user_input):
    user_input = check_date(user_input)
    check_format = False if len(user_input) != 10 else True
    return check_format, user_input


def datelst_input(user_input):
    user_input = return_list(user_input, "listdate")
    return user_input


def print_out(input_lst):
    output_lst = []
    for i in input_lst:
        if type(i) == str:
            output_lst.append(i)
        elif isinstance(i, float):
            output_lst.append(f"{i:,.2f}")
        elif isinstance(i, int):
            output_lst.append(f"{i:,}")
        else:
            output_lst.append(str(i)[1:-1].replace("'", "").replace(", ", " - "))
    return output_lst
