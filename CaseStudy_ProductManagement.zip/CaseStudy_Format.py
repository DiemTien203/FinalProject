from tkinter import *
from tkinter.ttk import *
import tkinter as tk
import tksheet

# Format
font_name = "serif 10"
font_title1 = (font_name, 18, "bold")
font_title2 = (font_name, 14, "bold")
font_text = (font_name, 12, "normal")
font_note = (font_name, 13, "italic")
font_btn = (font_name, 12, "bold")


class Content:
    def __init__(self, parent, var_lst, wd_title):
        self.parent = parent
        self.frame = tk.Frame(self.parent, background="grey93")
        self.var_lst = var_lst
        self.parent.title(wd_title)
        self.parent.resizable(False, False)

        st = Style()
        st.configure('W.TButton', foreground="royalblue", font=font_btn)

        code_ttl = Label(self.frame, text=f"Product Code: {self.var_lst[0]}", font=font_title1, foreground="red")
        code_ttl.grid(row=0, column=0, columnspan=4)

        cate_ttl = Label(self.frame, text="Category", font=font_title2)
        cate_ttl.grid(row=1, column=2)
        cate_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        cate_var.insert(INSERT, self.var_lst[1])
        cate_var.grid(row=1, column=3)

        name_ttl = Label(self.frame, text="Product Name", font=font_title2)
        name_ttl.grid(row=1, column=0)
        name_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        name_var.insert(INSERT, self.var_lst[2])
        name_var.grid(row=1, column=1)

        desc_ttl = Label(self.frame, text="Description", font=font_title2)
        desc_ttl.grid(row=2, column=0)
        desc_var = Text(self.frame, wrap=WORD, width=20, height=2,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        desc_var.insert(INSERT, self.var_lst[3])
        desc_var.grid(row=2, column=1)

        mate_ttl = Label(self.frame, text="Material", font=font_title2)
        mate_ttl.grid(row=3, column=0)
        mate_var = Text(self.frame, wrap=WORD, width=20, height=2,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        mate_var.insert(INSERT, self.var_lst[4])
        mate_var.grid(row=3, column=1)

        splr_ttl = Label(self.frame, text="Supplier", font=font_title2)
        splr_ttl.grid(row=4, column=0)
        splr_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        splr_var.insert(INSERT, self.var_lst[5])
        splr_var.grid(row=4, column=1)

        lauc_ttl = Label(self.frame, text="Launching Date", font=font_title2)
        lauc_ttl.grid(row=5, column=0)
        lauc_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        lauc_var.insert(INSERT, self.var_lst[6])
        lauc_var.grid(row=5, column=1)

        seas_ttl = Label(self.frame, text="Season", font=font_title2)
        seas_ttl.grid(row=6, column=0)
        seas_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        seas_var.insert(INSERT, self.var_lst[7])
        seas_var.grid(row=6, column=1)

        prom_ttl = Label(self.frame, text="Promotion", font=font_title2)
        prom_ttl.grid(row=2, column=2)
        prom_var = Text(self.frame, wrap=WORD, width=20, height=2,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        prom_var.insert(INSERT, self.var_lst[10])
        prom_var.grid(row=2, column=3)

        nosm_ttl = Label(self.frame, text="No. of Shipment", font=font_title2)
        nosm_ttl.grid(row=3, column=2)
        nosm_var = Text(self.frame, wrap=WORD, width=20, height=2,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        nosm_var.insert(INSERT, self.var_lst[12])
        nosm_var.grid(row=3, column=3)

        last_ttl = Label(self.frame, text="Latest Arrival", font=font_title2)
        last_ttl.grid(row=4, column=2)
        last_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        last_var.insert(INSERT, self.var_lst[13])
        last_var.grid(row=4, column=3)

        cost_ttl = Label(self.frame, text="Cost", font=font_title2)
        cost_ttl.grid(row=5, column=2)
        cost_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        cost_var.insert(INSERT, f"{self.var_lst[8]}")
        cost_var.grid(row=5, column=3)

        sell_ttl = Label(self.frame, text="Selling Price", font=font_title2)
        sell_ttl.grid(row=6, column=2)
        sell_var = Text(self.frame, wrap=WORD, width=20, height=1,
                        background="white", font=font_text, borderwidth=0.5, relief="solid")
        sell_var.insert(INSERT, f"{self.var_lst[9]}")
        sell_var.grid(row=6, column=3)

        quit_btn = Button(self.frame, text="Close", command=lambda: self.parent.withdraw(), style='W.TButton')
        quit_btn.grid(row=7, column=3)

        self.frame.grid()


class AddContent:
    def __init__(self, parent):
        self.parent = parent
        self.frame = tk.Frame(self.parent, background="grey93")
        self.parent.title("ADD NEW PRODUCT")
        self.init_ui()
        self.parent.resizable(False, False)

    def get_entry(self):
        new_var = [self.code_var.get(), self.cate_var.get(), self.name_var.get(), self.desc_var.get(),
                   self.mate_var.get(), self.splr_var.get(), self.lauc_var.get(), self.seas_var.get(),
                   self.cost_var.get(), self.sell_var.get(), self.prom_var.get(), self.ship_var.get()]
        self.new_var = new_var
        self.parent.quit()

    def init_ui(self):
        code_ttl = Label(self.frame, text=f"Product Code", font=font_title1, foreground="red")
        code_ttl.grid(row=1, column=0)
        self.code_var = Entry(self.frame, width=20)
        self.code_var.grid(row=1, column=1)

        cate_ttl = Label(self.frame, text="Category", font=font_title2)
        cate_ttl.grid(row=1, column=2)
        self.cate_var = Entry(self.frame, width=20)
        self.cate_var.grid(row=1, column=3)

        name_ttl = Label(self.frame, text="Product Name", font=font_title2)
        name_ttl.grid(row=2, column=0)
        self.name_var = Entry(self.frame, width=20)
        self.name_var.grid(row=2, column=1)

        desc_ttl = Label(self.frame, text="Description", font=font_title2)
        desc_ttl.grid(row=3, column=0)
        self.desc_var = Entry(self.frame, width=20)
        self.desc_var.grid(row=3, column=1)

        mate_ttl = Label(self.frame, text="Material", font=font_title2)
        mate_ttl.grid(row=4, column=0)
        self.mate_var = Entry(self.frame, width=20)
        self.mate_var.grid(row=4, column=1)

        splr_ttl = Label(self.frame, text="Supplier", font=font_title2)
        splr_ttl.grid(row=5, column=0)
        self.splr_var = Entry(self.frame, width=20)
        self.splr_var.grid(row=5, column=1)

        lauc_ttl = Label(self.frame, text="Launching Date", font=font_title2)
        lauc_ttl.grid(row=6, column=0)
        self.lauc_var = Entry(self.frame, width=20)
        self.lauc_var.grid(row=6, column=1)

        seas_ttl = Label(self.frame, text="Season", font=font_title2)
        seas_ttl.grid(row=7, column=0)
        self.seas_var = Entry(self.frame, width=20)
        self.seas_var.grid(row=7, column=1)

        prom_ttl = Label(self.frame, text="Promotion", font=font_title2)
        prom_ttl.grid(row=2, column=2)
        self.prom_var = Entry(self.frame, width=20)
        self.prom_var.grid(row=2, column=3)

        ship_ttl = Label(self.frame, text="Shipment(s)", font=font_title2)
        ship_ttl.grid(row=3, column=2)
        self.ship_var = Entry(self.frame, width=20)
        self.ship_var.grid(row=3, column=3)

        cost_ttl = Label(self.frame, text="Cost", font=font_title2)
        cost_ttl.grid(row=4, column=2)
        self.cost_var = Entry(self.frame, width=20)
        self.cost_var.grid(row=4, column=3)

        sell_ttl = Label(self.frame, text="Selling Price", font=font_title2)
        sell_ttl.grid(row=5, column=2)
        self.sell_var = Entry(self.frame, width=20)
        self.sell_var.grid(row=5, column=3)

        Label(self.frame, text="Note: Date formated as dd/mm/yyyy", font=font_note).grid(row=6, column=2, columnspan=2)
        Label(self.frame, text="List elements separated by comma \",\"", font=font_note).grid(row=7, column=2,
                                                                                              columnspan=2)

        self.add_btn = Button(self.frame, text="Add", command=self.get_entry, style='W.TButton')
        self.add_btn.grid(row=8, column=2)
        quit_btn = Button(self.frame, text="Cancel", command=lambda: self.parent.withdraw(), style='W.TButton')
        quit_btn.grid(row=8, column=3)

        self.frame.grid()


class AdjustContent:
    def __init__(self, parent, old_info):
        self.parent = parent
        self.frame = tk.Frame(self.parent, background="grey93")
        self.parent.title("ADD NEW PRODUCT")
        self.old_info = old_info
        self.parent.resizable(False, False)
        self.init_ui()

    def get_entry(self):
        new_var = [self.code_var.get(), self.cate_var.get(), self.name_var.get(), self.desc_var.get(),
                   self.mate_var.get(), self.splr_var.get(), self.lauc_var.get(), self.seas_var.get(),
                   self.cost_var.get(), self.sell_var.get(), self.prom_var.get(), self.ship_var.get()]
        self.new_var = new_var
        self.parent.quit()

    def init_ui(self):
        code_ttl_1 = Label(self.frame, text=f"Product Code: {self.old_info[0]}", font=font_title1, foreground="red")
        code_ttl_1.grid(row=1, column=0, columnspan=4)

        cate_ttl_1 = Label(self.frame, text="Category", font=font_title2)
        cate_ttl_1.grid(row=2, column=2)
        cate_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        cate_var_1.insert(INSERT, self.old_info[1])
        cate_var_1.grid(row=2, column=3)

        name_ttl_1 = Label(self.frame, text="Product Name", font=font_title2)
        name_ttl_1.grid(row=2, column=0)
        name_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        name_var_1.insert(INSERT, self.old_info[2])
        name_var_1.grid(row=2, column=1)

        desc_ttl_1 = Label(self.frame, text="Description", font=font_title2)
        desc_ttl_1.grid(row=3, column=0)
        desc_var_1 = Text(self.frame, wrap=WORD, width=20, height=2,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        desc_var_1.insert(INSERT, self.old_info[3])
        desc_var_1.grid(row=3, column=1)

        mate_ttl_1 = Label(self.frame, text="Material", font=font_title2)
        mate_ttl_1.grid(row=4, column=0)
        mate_var_1 = Text(self.frame, wrap=WORD, width=20, height=2,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        mate_var_1.insert(INSERT, self.old_info[4])
        mate_var_1.grid(row=4, column=1)

        splr_ttl_1 = Label(self.frame, text="Supplier", font=font_title2)
        splr_ttl_1.grid(row=5, column=0)
        splr_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        splr_var_1.insert(INSERT, self.old_info[5])
        splr_var_1.grid(row=5, column=1)

        lauc_ttl_1 = Label(self.frame, text="Launching Date", font=font_title2)
        lauc_ttl_1.grid(row=6, column=0)
        lauc_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        lauc_var_1.insert(INSERT, self.old_info[6])
        lauc_var_1.grid(row=6, column=1)

        seas_ttl_1 = Label(self.frame, text="Season", font=font_title2)
        seas_ttl_1.grid(row=7, column=0)
        seas_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        seas_var_1.insert(INSERT, self.old_info[7])
        seas_var_1.grid(row=7, column=1)

        prom_ttl_1 = Label(self.frame, text="Promotion", font=font_title2)
        prom_ttl_1.grid(row=3, column=2)
        prom_var_1 = Text(self.frame, wrap=WORD, width=20, height=2,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        prom_var_1.insert(INSERT, self.old_info[10])
        prom_var_1.grid(row=3, column=3)

        ship_ttl_1 = Label(self.frame, text="Shipment(s)", font=font_title2)
        ship_ttl_1.grid(row=4, column=2, rowspan=2)
        ship_var_1 = Text(self.frame, wrap=WORD, width=20, height=2,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        ship_var_1.insert(INSERT, self.old_info[11])
        ship_var_1.grid(row=4, column=3, rowspan=2)

        cost_ttl_1 = Label(self.frame, text="Cost", font=font_title2)
        cost_ttl_1.grid(row=6, column=2)
        cost_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        cost_var_1.insert(INSERT, f"{self.old_info[8]:,.2f}")
        cost_var_1.grid(row=6, column=3)

        sell_ttl_1 = Label(self.frame, text="Selling Price", font=font_title2)
        sell_ttl_1.grid(row=7, column=2)
        sell_var_1 = Text(self.frame, wrap=WORD, width=20, height=1,
                          background="white", font=font_text, borderwidth=0.5, relief="solid")
        sell_var_1.insert(INSERT, f"{self.old_info[9]:,.2f}")
        sell_var_1.grid(row=7, column=3)

        Label(self.frame, text="NEW INFORMATION", font=font_title1, foreground="red") \
            .grid(row=8, column=0, columnspan=4)
        code_ttl = Label(self.frame, text="Product Code", font=font_title2)
        code_ttl.grid(row=9, column=0)
        self.code_var = Entry(self.frame, width=20)
        self.code_var.grid(row=9, column=1)

        cate_ttl = Label(self.frame, text="Category", font=font_title2)
        cate_ttl.grid(row=9, column=2)
        self.cate_var = Entry(self.frame, width=20)
        self.cate_var.grid(row=9, column=3)

        name_ttl = Label(self.frame, text="Product Name", font=font_title2)
        name_ttl.grid(row=10, column=0)
        self.name_var = Entry(self.frame, width=20)
        self.name_var.grid(row=10, column=1)

        desc_ttl = Label(self.frame, text="Description", font=font_title2)
        desc_ttl.grid(row=11, column=0)
        self.desc_var = Entry(self.frame, width=20)
        self.desc_var.grid(row=11, column=1)

        mate_ttl = Label(self.frame, text="Material", font=font_title2)
        mate_ttl.grid(row=12, column=0)
        self.mate_var = Entry(self.frame, width=20)
        self.mate_var.grid(row=12, column=1)

        splr_ttl = Label(self.frame, text="Supplier", font=font_title2)
        splr_ttl.grid(row=13, column=0)
        self.splr_var = Entry(self.frame, width=20)
        self.splr_var.grid(row=13, column=1)

        lauc_ttl = Label(self.frame, text="Launching Date", font=font_title2)
        lauc_ttl.grid(row=14, column=0)
        self.lauc_var = Entry(self.frame, width=20)
        self.lauc_var.grid(row=14, column=1)

        seas_ttl = Label(self.frame, text="Season", font=font_title2)
        seas_ttl.grid(row=15, column=0)
        self.seas_var = Entry(self.frame, width=20)
        self.seas_var.grid(row=15, column=1)

        prom_ttl = Label(self.frame, text="Promotion", font=font_title2)
        prom_ttl.grid(row=10, column=2)
        self.prom_var = Entry(self.frame, width=20)
        self.prom_var.grid(row=10, column=3)

        ship_ttl = Label(self.frame, text="Shipment(s)", font=font_title2)
        ship_ttl.grid(row=11, column=2)
        self.ship_var = Entry(self.frame, width=20)
        self.ship_var.grid(row=11, column=3)

        cost_ttl = Label(self.frame, text="Cost", font=font_title2)
        cost_ttl.grid(row=12, column=2)
        self.cost_var = Entry(self.frame, width=20)
        self.cost_var.grid(row=12, column=3)

        sell_ttl = Label(self.frame, text="Selling Price", font=font_title2)
        sell_ttl.grid(row=13, column=2)
        self.sell_var = Entry(self.frame, width=20)
        self.sell_var.grid(row=13, column=3)

        Label(self.frame, text="Note: Date formated as dd/mm/yyyy", font=font_note).grid(row=14, column=2, columnspan=2)
        Label(self.frame, text="List elements separated by comma \",\"", font=font_note).grid(row=15, column=2,
                                                                                              columnspan=2)
        self.add_btn = Button(self.frame, text="Change", command=self.get_entry, style='W.TButton')
        self.add_btn.grid(row=16, column=2)
        quit_btn = Button(self.frame, text="Cancel", command=lambda: self.parent.withdraw(), style='W.TButton')
        quit_btn.grid(row=16, column=3)

        self.frame.grid()


class DataSheet:
    def __init__(self, parent, input_array):
        self.parent = parent
        # Sheet
        self.sheet = tksheet.Sheet(parent, total_rows=30, total_columns=20,
                                   column_width=80,
                                   font=font_text, set_all_heights_and_widths=True)
        self.data_array = input_array
        self.sheet.grid(row=0, column=0, sticky="nswe", padx=10, pady=10)
        self.sheet.set_sheet_data(
            [[f"{self.data_array[i][j]}" for j in range(len(self.data_array[0]))] for i in range(len(self.data_array))])
        self.sheet.enable_bindings()
        # Close button
        self.frame = tk.Frame(self.parent, background="grey93")
        quit_btn = Button(self.frame, text="Close", command=lambda: self.parent.withdraw(), style='W.TButton')
        quit_btn.grid(row=1, column=8)
        self.frame.grid()

