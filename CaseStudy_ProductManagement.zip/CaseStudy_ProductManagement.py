from tkinter import *
from tkinter.ttk import *
import CaseStudy_Format as Fm
import CaseStudy_RawData as Rd
import CaseStudy_FuncLst as Func
import tkinter.messagebox as mbox
import tkinter as tk

product_app = Tk()

# Program layout
product_app.geometry("800x300+400+100")
product_app.resizable(False, True)
product_app.grid_columnconfigure(0, weight=5)
product_app.grid_columnconfigure(1, weight=5)
product_app.grid_columnconfigure(2, weight=5)
product_app.grid_columnconfigure(3, weight=5)


product_app.title("PRODUCT MANAGEMENT")
product_app.configure(bg="grey93")
st = Style()
st.configure('W.TButton', foreground="royalblue", font=Fm.font_btn)


# Program display
code_ttl = Label(master=product_app, text="Product Code", font=Fm.font_title1, foreground="royalblue")
code_ttl.grid(row=0, column=0)
code_var = Entry(master=product_app, width=16)
code_var.grid(row=0, column=1, sticky="ew", columnspan=2)


# Program command

def show_wd():
    pro_code = str(code_var.get())
    if pro_code == "":
        mbox.showinfo(title=None, message="You have not input the product code!")
    elif pro_code not in Rd.all_product:
        mbox.showerror(title=None, message="No information")
    else:
        print_info(pro_code, "show")


def print_info(pro_code, func_type):
    var_lst = Rd.all_product[pro_code]
    product_mnm = tk.Toplevel(product_app)
    if func_type == "show":
        Fm.Content(product_mnm, Func.print_out(var_lst), "PRODUCT INFORMATION")
    elif func_type == "showadjust":
        Fm.Content(product_mnm, Func.print_out(var_lst), "ADJUSTED INFORMATION")
    elif func_type == "shownew":
        Fm.Content(product_mnm, Func.print_out(var_lst), "NEW ADDED INFORMATION")


def adjust_wd():
    pro_code = str(code_var.get())
    if pro_code == "":
        mbox.showinfo(title=None, message="You have not input the product code!")
    elif pro_code not in Rd.all_product:
        mbox.showerror(title=None, message="No information")
    else:
        adjust_info(pro_code)


def adjust_info(pro_code):
    var_lst = Rd.all_product[pro_code]
    product_adj = tk.Toplevel(product_app)
    wd3 = Fm.AdjustContent(product_adj, var_lst)
    product_adj.mainloop()

    new_var_lst = wd3.new_var
    new_pro_code = Rd.adjust_info(new_var_lst, var_lst[0:12])
    product_adj.withdraw()
    print_info(new_pro_code[0], "showadjust")


def add_wd():
    product_add = tk.Toplevel(product_app)
    wd2 = Fm.AddContent(product_add)
    product_add.mainloop()
    new_var_lst = wd2.new_var
    new_pro_lst = Rd.add_product(new_var_lst)
    product_add.withdraw()
    print_info(new_pro_lst[0], "shownew")


def show_all():
    product_sheet = tk.Toplevel(product_app)
    product_sheet.geometry("1200x600")
    product_sheet.grid_columnconfigure(0, weight=1)
    product_sheet.grid_rowconfigure(0, weight=1)
    Fm.DataSheet(product_sheet, Rd.shorted_data())


def retrieve_filelink(textbox, func):
    if func == "input":
        try:
            Rd.open_data(textbox.get("1.0", "end-1c"))
            mbox.showinfo(title=None, message="New data has been imported!")
        except Exception:
            mbox.showerror(title=None, message=f"""
            File in {textbox.get("1.0", "end-1c")} is not formatted right.

            Check default file in {Rd.data_link} to reformat your new file!""")
            inputlnk_var.delete("1.0", "end")
            inputlnk_var.insert(INSERT, Rd.data_link)
    elif func == "output":
        Rd.save_link = textbox.get("1.0", "end-1c")
        mbox.showinfo(title=None, message="Change has been applied!")


def quit_btn():
    save_choice = mbox.askyesno("askyesno", f"Save your change into \"{Rd.save_link}\"?")
    if save_choice == 'yes':
        Rd.save_data(Rd.save_link)
    else:
        quit()


# Main button
show_btn = Button(master=product_app, text="Show", command=show_wd, style='W.TButton')
show_btn.grid(row=0, column=3, sticky="ew")

list_btn = Button(master=product_app, text="Show all products", command=show_all, style='W.TButton')
list_btn.grid(row=1, column=0, sticky="ew")

addj_btn = Button(master=product_app, text="Adjust data", command=adjust_wd, style='W.TButton')
addj_btn.grid(row=1, column=1, sticky="ew")

adpr_btn = Button(master=product_app, text="Add new product", command=add_wd, style='W.TButton')
adpr_btn.grid(row=1, column=2, sticky="ew")

quit_btn = Button(master=product_app, text="Quit", command=quit_btn, style='W.TButton')
quit_btn.grid(row=1, column=3, sticky="ew")

# Change input/output link
inputlnk_lbl = Label(master=product_app, text="Data source link", font=Fm.font_title1, foreground="firebrick")
inputlnk_lbl.grid(row=2, column=0, columnspan=4)

inputlnk_lbl = Label(master=product_app, text="Data input", font=Fm.font_note, foreground="firebrick")
inputlnk_lbl.grid(row=3, column=0)
inputlnk_var = Text(master=product_app, wrap=WORD, width=30, height=2,
                    font=Fm.font_note)
inputlnk_var.insert(INSERT, Rd.data_link)
inputlnk_var.grid(row=3, column=1, columnspan=2, sticky="ew")
getinput_btn = Button(master=product_app, text="Change input data",
                      command=lambda: retrieve_filelink(inputlnk_var, "input"))
getinput_btn.grid(row=3, column=3)

outputlnk_lbl = Label(master=product_app, text="Data save", font=Fm.font_note, foreground="firebrick")
outputlnk_lbl.grid(row=4, column=0)
outputlnk_var = Text(master=product_app, wrap=WORD, width=30, height=2,
                     font=Fm.font_note)
outputlnk_var.insert(INSERT, Rd.save_link)
outputlnk_var.grid(row=4, column=1, columnspan=2, sticky="ew")
getinput_btn = Button(master=product_app, text="Change output file",
                      command=lambda: retrieve_filelink(inputlnk_var, "output"))
getinput_btn.grid(row=4, column=3)

mainloop()
