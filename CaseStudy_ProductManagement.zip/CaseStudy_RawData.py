import CaseStudy_FuncLst as Func
import csv


class ProductInfo:
    """Production raw information"""

    def __init__(self, var_lst):
        self.code = var_lst[0]
        self.category = var_lst[1]
        self.name = var_lst[2]
        self.description = var_lst[3]
        self.material = var_lst[4]
        self.supplier = var_lst[5]
        self.launching_date = var_lst[6]
        self.season = var_lst[7]
        self.cost = var_lst[8]
        self.price = var_lst[9]
        self.promotion = var_lst[10]
        self.shipment = var_lst[11]

    # set value
    def set_code(self, code):
        self.code = code

    def set_category(self, category):
        self.category = category

    def set_name(self, name):
        self.name = name

    def set_description(self, description):
        self.description = description

    def set_material(self, material):
        self.material = material

    def set_supplier(self, supplier):
        self.supplier = supplier

    def set_launchingdate(self, launching_date):
        self.launching_date = launching_date

    def set_season(self, season):
        self.season = season

    def set_cost(self, cost):
        self.cost = cost

    def set_price(self, price):
        self.price = price

    def set_promotion(self, promotion):
        self.promotion = promotion

    def set_shipment(self, shipment):
        self.shipment = shipment

    # add value
    def add_material(self, material):
        self.material.append(material)

    def add_supplier(self, supplier):
        self.supplier.append(supplier)

    def add_season(self, season):
        self.season.append(season)

    def add_shipment(self, shipment):
        self.shipment.append(shipment)

    # others
    def valid_sm(self):
        valid_sm = []
        for sm in self.shipment:
            if len(sm) == 10:
                valid_sm.append(sm)
        return valid_sm

    def no_shipment(self):
        if self.shipment:
            if len(self.valid_sm()) > 1:
                out_str = str(len(self.valid_sm())) + " shipments " + str(Func.print_out(self.shipment))
            else:
                out_str = str(len(self.valid_sm())) + " shipment " + str(Func.print_out(self.shipment))
        else:
            out_str = ""
        return out_str

    def last_shipment(self):
        dd_lst = []
        mm_lst = []
        yy_lst = []
        for shipment in self.valid_sm():
            dd_lst.append(int(shipment[0:2]))
            mm_lst.append(int(shipment[3:5]))
            yy_lst.append(int(shipment[6:]))
        dd_max = 0
        mm_max = 0
        yy_max = 0
        for i in range(len(yy_lst)):
            if yy_lst[i] >= yy_max:
                yy_max = yy_lst[i]
        yy_pos = []
        for i in range(len(yy_lst)):
            if yy_lst[i] == yy_max:
                yy_pos.append(i)
        for j in yy_pos:
            if mm_lst[j] >= mm_max:
                mm_max = mm_lst[j]
        mm_pos = []
        for j in yy_pos:
            if mm_lst[j] == mm_max:
                mm_pos.append(j)
        for k in mm_pos:
            if dd_lst[k] >= dd_max:
                dd_max = dd_lst[k]
        dd_pos = []
        for k in mm_pos:
            if dd_lst[k] == dd_max:
                dd_pos.append(k)
        if len(dd_pos) > 0:
            string_output = str(len(dd_pos)) + " shipments on " + self.valid_sm()[dd_pos[0]] if len(dd_pos) > 1 \
                else str(len(dd_pos)) + " shipment on " + self.valid_sm()[dd_pos[0]]
        else:
            string_output = ""
        return string_output


# Data Function

def proinfo_dict(var):
    pro_dict = {var.code: [var.code, var.category, var.name, var.description, var.material,
                           var.supplier, var.launching_date, var.season, var.cost, var.price, var.promotion,
                           var.shipment, var.no_shipment(), var.last_shipment()]}
    return pro_dict


def add_to_allproduct(product_lst):
    new_product = ProductInfo(product_lst)
    pro_info = proinfo_dict(new_product)
    all_product.update(pro_info)


def add_product(user_input):  # return product information as dictionary
    """user input: code, cate, name, description, material (list), supplier (list), launching date (date),
    season (list), cost (float list), selling price (float list), promotion, shipments (date list)"""
    variables = ["", "", "", "", "", "", "", "", "", "", "", ""]
    for i in range(len(user_input)):
        if user_input[i] != "":
            if i == 0:
                if len(user_input[i]) < 8:
                    variables[i] = "0"*(8-len(user_input[i])) + user_input[i]
                else:
                    variables[i] = user_input[i]
            elif i == 1:
                if len(user_input[i]) < 4:
                    variables[i] = "0"*(4-len(user_input[i])) + user_input[i]
                else:
                    variables[i] = user_input[i]
            elif i in (2, 3, 10):
                variables[i] = user_input[i]
            elif i in (4, 5, 7):
                variables[i] = Func.lst_input(user_input[i])
            elif i == 6:
                variables[i] = Func.check_date(user_input[i])
            elif i in (8, 9):
                try:
                    variables[i] = float(user_input[i])
                except ValueError:
                    no_str = user_input[i].find(".")
                    variables[i] = float(user_input[i][0:no_str].replace(",", ""))
            elif i == 11:
                variables[i] = Func.datelst_input(user_input[i])
    add_to_allproduct(variables)
    return variables


def adjust_info(user_input, var_list):
    adjust_lst = ["", "", "", "", "", "", "", "", "", "", "", ""]
    if user_input[0] != "":
        for i in range(1, len(var_list)):
            var_list[i] = f"deleted, replaced by {user_input[0]}"
        add_to_allproduct(var_list)
    else:
        for i in range(len(user_input)):
            if user_input[i] != "":
                adjust_lst[i] = user_input[i]
            else:
                adjust_lst[i] = var_list[i]
        add_to_allproduct(adjust_lst)
    return adjust_lst


def find_product(pro_code):
    return pro_code in all_product


def shorted_data():
    shorted_lst = [row_value[0]]
    for keys in all_product:
        pro_info = all_product[keys]
        value_list = Func.print_out(pro_info)
        shorted_lst.append(value_list)
    return shorted_lst


def open_data(file_link):
    row_lst = []
    with open(file_link, 'rt') as f:
        data = csv.reader(f, delimiter=",")
        for row in data:
            row_lst.append(row)
    for i in range(1, len(row_lst)):
        add_product(row_lst[i])
    return row_lst


def save_data(file_link):
    with open(file_link, mode='w') as csv_file:
        employee_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        for product in shorted_data():
            employee_writer.writerow(product)


data_link = '/Users/DiemTien/Demo_Git/CodeGym/Case Study/CaseStudy_Data.csv'
save_link = '/Users/DiemTien/Demo_Git/CodeGym/Case Study/CaseStudy_DataSave.csv'
default_lst = ["", "", "", "", "", "", "", "", "", "", "", ""]
all_product = {}
row_value = open_data(data_link)
